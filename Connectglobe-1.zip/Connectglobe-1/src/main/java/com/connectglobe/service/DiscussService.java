package com.connectglobe.service;

public interface DiscussService {

}
