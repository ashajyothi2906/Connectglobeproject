package com.connectglobe.service;

public interface UserDetailsService {

}
