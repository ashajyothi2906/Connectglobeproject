package com.connectglobe.service;

public interface TopicDetailsService {

}
