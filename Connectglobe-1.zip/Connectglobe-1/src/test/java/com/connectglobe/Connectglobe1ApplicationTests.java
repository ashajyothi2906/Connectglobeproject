package com.connectglobe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Connectglobe1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
